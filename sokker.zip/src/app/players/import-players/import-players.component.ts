import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-import-players',
  templateUrl: './import-players.component.html',
  styleUrls: ['./import-players.component.css']
})
export class ImportPlayersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
